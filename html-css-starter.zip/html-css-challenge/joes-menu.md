APPETIZERS 
name: Cranberry Brie Bread 
description: gooey brie topped with sweet cranberries on a crusty loaf of sourdough 
price: $18.00 

name: Korean Beef Lettuce Wraps 
description: bulgogi beef wrapped in little lettuce packages with homemade pickled onions and radishes, topped with miso mayo 
price: $14.00 

name: Spinach-Stuffed Mushrooms 
description: creamy, garlicky, spinach stuffed mushrooms topped with bubbling parmesan cheese 
price: $12.00 


MAINS
name: Apple and Onion Pork Chops 
description: hearty fall flavours served with brussels sprouts with toasted hazelnut butter and an in house made french roll 
price: $24.00

name: Grilled Moroccan Chicken 
description: fragrant chicken cooked with garlic, lemon, and pomegranate molasses served with roasted turmeric cauliflower topped with creamy yogurt 
price: $26.00 

name: Grilled Lobster Tails with Coriander 
description: fresh and tender lobster tails seasoned with coriander and topped with warm chilli butter sauce 
price: $32.00 

Dried Tomato Florentine Pasta 
description: spicy pasta cooked in a sun dried tomato cream sauce topped with spinach and mozzarella 
price: $22.00


SALADS
name: Broccoli and Apple Salad with Chicken 
description: charred broccoli, sweet fuji apples, feta cheese and warm grilled chicken breast served on a bed of mixed greens 
price: $18.00 

name: Persimmon, Pomegranate, and Kale Salad 
description: massaged seasoned kale salad served with a delicious tangy citrus dressing 
price: $14.00 

name: Peach, Sweet Corn and Halloumi Salad 
description: fresh sweet corn and juicy peaches served with salty halloumi cheese on arugula 
price: $22.00 


DESSERTS
name: Salted Caramel White Chocolate Brownies 
description: decadent gooey white chocolate brownies layered with in house made caramel 
price: $12 

name: Cinnamon Sugar Pretzel Bites 
description: warm fried dough covered in cinnamon sugar served with chocolate sauce for dipping 
price: $8 


DEALS
monday $3 off vegetarian salads and mains 
tuesday $2 off bar rail 
wednesday half-priced appetizers after 9pm 
thursday $2 off cocktails 
friday one free dessert with the purchase 2 mains
